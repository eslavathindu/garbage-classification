
# Garbage Classification using CNN 🧠🗑️

A Convolutional Neural Network (CNN) model to classify types of garbage like plastic, metal, paper, etc.

## 📂 Dataset Structure
```
dataset/
├── plastic/
├── paper/
├── metal/
├── cardboard/
├── glass/
└── trash/
```

## 🚀 How to Run

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Train the model:
```bash
python train.py
```

3. Predict using a test image:
```bash
python predict.py
```

## 👩‍💻 Author
**eslavathindu**

---
